// app/patient/vitals/glucometer.js
import DeviceScreen from '../../../components/DeviceScreen';
import { COLORS } from '../../../constants/theme';

const CONFIG = {
  id:           'glucometer',
  name:         'Glucometer',
  emoji:        '🩸',
  color:        COLORS.deviceGluco,
  instructions: 'Clean the fingertip with an alcohol swab and let it dry. Apply the lancet to draw a small blood drop. Touch the test strip edge to the drop and wait for the result.',
  readings: [
    { key: 'glucoseMgDl', label: 'Blood Glucose (mg/dL)', unit: 'mg/dL', simulate: () => Math.floor(Math.random() * 120 + 80) },
    { key: 'glucoseMmol', label: 'Blood Glucose (mmol/L)', unit: 'mmol/L', simulate: () => (Math.random() * 6.7 + 4.4).toFixed(1) },
    { key: 'testTime',    label: 'Time Since Last Meal',   unit: 'hrs',    simulate: () => (Math.random() * 8 + 1).toFixed(1) },
  ],
};

export default function GlucometerScreen() {
  return <DeviceScreen config={CONFIG} />;
}
