// app/register.js — Register Screen
import React, { useState } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity,
  ScrollView, KeyboardAvoidingView, Platform, Alert,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import FormInput from '../components/FormInput';
import { COLORS, FONT_SIZE, FONT_WEIGHT, RADIUS, SPACING, shadow } from '../constants/theme';

const ROLES = ['Registered Nurse', 'CNA', 'Home Health Aide', 'Physical Therapist', 'Care Coordinator', 'Physician', 'Other'];

export default function RegisterScreen() {
  const router = useRouter();

  const [form, setForm] = useState({
    firstName: '', lastName: '', email: '', phone: '',
    organization: '', role: '', password: '', confirmPassword: '',
  });
  const [selectedRole, setSelectedRole] = useState('');
  const [agreeTerms, setAgreeTerms]     = useState(false);
  const [loading, setLoading]           = useState(false);
  const [step, setStep]                 = useState(1); // 1 = personal, 2 = professional, 3 = security

  const update = (key) => (val) => setForm((p) => ({ ...p, [key]: val }));

  const handleNext = () => {
    if (step === 1) {
      if (!form.firstName || !form.lastName || !form.email) {
        Alert.alert('Required', 'Please fill in all required fields.'); return;
      }
      setStep(2);
    } else if (step === 2) {
      if (!selectedRole) {
        Alert.alert('Required', 'Please select your role.'); return;
      }
      setStep(3);
    }
  };

  const handleSubmit = () => {
    if (!form.password || form.password.length < 8) {
      Alert.alert('Weak Password', 'Password must be at least 8 characters.'); return;
    }
    if (form.password !== form.confirmPassword) {
      Alert.alert('Mismatch', 'Passwords do not match.'); return;
    }
    if (!agreeTerms) {
      Alert.alert('Terms', 'Please agree to the Terms & Privacy Policy.'); return;
    }
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      Alert.alert('Account Created!', 'Welcome to CareGiver. Please sign in.', [
        { text: 'Sign In', onPress: () => router.replace('/') },
      ]);
    }, 1600);
  };

  const stepTitles  = ['Personal Info', 'Professional Details', 'Account Security'];
  const stepIcons   = ['person-outline', 'briefcase-outline', 'shield-checkmark-outline'];

  return (
    <SafeAreaView style={styles.safe}>
      {/* Top gradient bar */}
      <LinearGradient colors={[COLORS.primary, COLORS.primaryMid]} style={styles.header}>
        <TouchableOpacity style={styles.backBtn} onPress={() => (step > 1 ? setStep(s => s - 1) : router.back())}>
          <Ionicons name="chevron-back" size={22} color={COLORS.white} />
        </TouchableOpacity>
        <View style={{ flex: 1 }}>
          <Text style={styles.headerTitle}>Create Account</Text>
          <Text style={styles.headerSub}>Step {step} of 3 · {stepTitles[step - 1]}</Text>
        </View>
      </LinearGradient>

      {/* Progress bar */}
      <View style={styles.progressBar}>
        <View style={[styles.progressFill, { width: `${(step / 3) * 100}%` }]} />
      </View>

      {/* Step indicators */}
      <View style={styles.steps}>
        {stepTitles.map((t, i) => (
          <View key={t} style={styles.stepItem}>
            <View style={[styles.stepCircle, i + 1 <= step && styles.stepCircleActive]}>
              {i + 1 < step
                ? <Ionicons name="checkmark" size={14} color={COLORS.white} />
                : <Ionicons name={stepIcons[i]} size={14} color={i + 1 === step ? COLORS.white : COLORS.textMuted} />
              }
            </View>
            <Text style={[styles.stepLabel, i + 1 === step && styles.stepLabelActive]}>{t}</Text>
          </View>
        ))}
      </View>

      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={{ flex: 1 }}>
        <ScrollView contentContainerStyle={styles.body} showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled">

          {/* ─── Step 1: Personal ─── */}
          {step === 1 && (
            <View style={styles.card}>
              <Text style={styles.sectionTitle}>Personal Information</Text>
              <View style={styles.row}>
                <FormInput label="First Name" value={form.firstName} onChangeText={update('firstName')} placeholder="Jane" icon="person-outline" required containerStyle={{ flex: 1, marginRight: 8 }} />
                <FormInput label="Last Name"  value={form.lastName}  onChangeText={update('lastName')}  placeholder="Doe"  icon="person-outline" required containerStyle={{ flex: 1 }} />
              </View>
              <FormInput label="Email Address" value={form.email} onChangeText={update('email')} placeholder="jane@hospital.com" keyboardType="email-address" autoCapitalize="none" icon="mail-outline" required />
              <FormInput label="Phone Number"  value={form.phone} onChangeText={update('phone')} placeholder="+1 (555) 000-0000" keyboardType="phone-pad" icon="call-outline" />
            </View>
          )}

          {/* ─── Step 2: Professional ─── */}
          {step === 2 && (
            <View style={styles.card}>
              <Text style={styles.sectionTitle}>Professional Details</Text>
              <FormInput label="Organization / Hospital" value={form.organization} onChangeText={update('organization')} placeholder="Memorial General Hospital" icon="business-outline" />

              <Text style={styles.roleLabel}>Your Role <Text style={{ color: COLORS.danger }}>*</Text></Text>
              <View style={styles.roleGrid}>
                {ROLES.map((r) => (
                  <TouchableOpacity
                    key={r}
                    style={[styles.roleChip, selectedRole === r && styles.roleChipActive]}
                    onPress={() => setSelectedRole(r)}
                  >
                    <Text style={[styles.roleChipText, selectedRole === r && styles.roleChipTextActive]}>{r}</Text>
                  </TouchableOpacity>
                ))}
              </View>

              <View style={styles.infoBox}>
                <Ionicons name="shield-checkmark-outline" size={16} color={COLORS.secondary} />
                <Text style={styles.infoBoxText}>Your professional credentials are securely verified during onboarding.</Text>
              </View>
            </View>
          )}

          {/* ─── Step 3: Security ─── */}
          {step === 3 && (
            <View style={styles.card}>
              <Text style={styles.sectionTitle}>Account Security</Text>
              <FormInput label="Password" value={form.password} onChangeText={update('password')} placeholder="Min. 8 characters" secureTextEntry icon="lock-closed-outline" required hint="Use a mix of letters, numbers, and symbols." />
              <FormInput label="Confirm Password" value={form.confirmPassword} onChangeText={update('confirmPassword')} placeholder="Re-enter password" secureTextEntry icon="lock-closed-outline" required />

              {/* Terms checkbox */}
              <TouchableOpacity style={styles.termsRow} onPress={() => setAgreeTerms((v) => !v)}>
                <View style={[styles.checkbox, agreeTerms && styles.checkboxChecked]}>
                  {agreeTerms && <Ionicons name="checkmark" size={13} color={COLORS.white} />}
                </View>
                <Text style={styles.termsText}>
                  I agree to the{' '}
                  <Text style={styles.termsLink}>Terms of Service</Text>
                  {' '}and{' '}
                  <Text style={styles.termsLink}>Privacy Policy</Text>
                </Text>
              </TouchableOpacity>

              <View style={styles.infoBox}>
                <Ionicons name="information-circle-outline" size={16} color={COLORS.secondary} />
                <Text style={styles.infoBoxText}>CareGiver is HIPAA-compliant. Your data is encrypted end-to-end.</Text>
              </View>
            </View>
          )}

          {/* Actions */}
          <View style={styles.actionArea}>
            {step < 3
              ? (
                <TouchableOpacity style={styles.primaryBtn} onPress={handleNext}>
                  <Text style={styles.primaryBtnText}>Continue</Text>
                  <Ionicons name="arrow-forward" size={18} color={COLORS.white} style={{ marginLeft: 8 }} />
                </TouchableOpacity>
              )
              : (
                <TouchableOpacity
                  style={[styles.primaryBtn, loading && { opacity: 0.7 }]}
                  onPress={handleSubmit}
                  disabled={loading}
                >
                  <Text style={styles.primaryBtnText}>{loading ? 'Creating Account…' : 'Create Account'}</Text>
                  {!loading && <Ionicons name="checkmark-circle-outline" size={18} color={COLORS.white} style={{ marginLeft: 8 }} />}
                </TouchableOpacity>
              )
            }

            <View style={styles.signInRow}>
              <Text style={styles.signInLabel}>Already have an account? </Text>
              <TouchableOpacity onPress={() => router.replace('/')}>
                <Text style={styles.signInLink}>Sign In</Text>
              </TouchableOpacity>
            </View>
          </View>

        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe:        { flex: 1, backgroundColor: COLORS.background },
  header:      { flexDirection: 'row', alignItems: 'center', paddingHorizontal: SPACING.md, paddingVertical: SPACING.md },
  backBtn:     { padding: 6, borderRadius: RADIUS.full, backgroundColor: 'rgba(255,255,255,0.15)', marginRight: SPACING.sm },
  headerTitle: { fontSize: FONT_SIZE.lg, fontWeight: FONT_WEIGHT.bold, color: COLORS.white },
  headerSub:   { fontSize: FONT_SIZE.xs, color: 'rgba(255,255,255,0.7)', marginTop: 2 },

  progressBar: { height: 3, backgroundColor: COLORS.divider },
  progressFill:{ height: 3, backgroundColor: COLORS.secondary },

  steps:       { flexDirection: 'row', justifyContent: 'space-around', paddingVertical: SPACING.sm, backgroundColor: COLORS.white, borderBottomWidth: 1, borderBottomColor: COLORS.divider },
  stepItem:    { alignItems: 'center', gap: 4 },
  stepCircle:  { width: 28, height: 28, borderRadius: 14, backgroundColor: COLORS.divider, alignItems: 'center', justifyContent: 'center' },
  stepCircleActive: { backgroundColor: COLORS.secondary },
  stepLabel:   { fontSize: FONT_SIZE.xs, color: COLORS.textMuted },
  stepLabelActive: { color: COLORS.secondary, fontWeight: FONT_WEIGHT.semibold },

  body:        { padding: SPACING.lg, paddingBottom: SPACING.xxl },
  card:        { backgroundColor: COLORS.white, borderRadius: RADIUS.lg, padding: SPACING.lg, ...shadow.sm, marginBottom: SPACING.md },
  sectionTitle:{ fontSize: FONT_SIZE.lg, fontWeight: FONT_WEIGHT.bold, color: COLORS.textDark, marginBottom: SPACING.md },

  row:         { flexDirection: 'row' },

  roleLabel:   { fontSize: FONT_SIZE.sm, fontWeight: FONT_WEIGHT.semibold, color: COLORS.textBody, marginBottom: SPACING.sm },
  roleGrid:    { flexDirection: 'row', flexWrap: 'wrap', gap: SPACING.sm, marginBottom: SPACING.md },
  roleChip:    { paddingHorizontal: SPACING.md, paddingVertical: 8, borderRadius: RADIUS.full, borderWidth: 1.5, borderColor: COLORS.divider, backgroundColor: COLORS.surface },
  roleChipActive: { borderColor: COLORS.secondary, backgroundColor: COLORS.accentLight + '40' },
  roleChipText:   { fontSize: FONT_SIZE.sm, color: COLORS.textMuted, fontWeight: FONT_WEIGHT.medium },
  roleChipTextActive: { color: COLORS.primaryMid, fontWeight: FONT_WEIGHT.bold },

  infoBox:     { flexDirection: 'row', alignItems: 'flex-start', backgroundColor: COLORS.infoBg, borderRadius: RADIUS.sm, padding: SPACING.sm, gap: 8, marginTop: SPACING.sm },
  infoBoxText: { flex: 1, fontSize: FONT_SIZE.xs, color: COLORS.info, lineHeight: 18 },

  termsRow:    { flexDirection: 'row', alignItems: 'flex-start', marginBottom: SPACING.md, gap: 10 },
  checkbox:    { width: 22, height: 22, borderRadius: 6, borderWidth: 2, borderColor: COLORS.divider, alignItems: 'center', justifyContent: 'center', marginTop: 1 },
  checkboxChecked: { backgroundColor: COLORS.secondary, borderColor: COLORS.secondary },
  termsText:   { flex: 1, fontSize: FONT_SIZE.sm, color: COLORS.textBody, lineHeight: 20 },
  termsLink:   { color: COLORS.secondary, fontWeight: FONT_WEIGHT.semibold },

  actionArea:  { gap: SPACING.md },
  primaryBtn:  { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', backgroundColor: COLORS.secondary, paddingVertical: 15, borderRadius: RADIUS.md, ...shadow.sm },
  primaryBtnText: { fontSize: FONT_SIZE.md, fontWeight: FONT_WEIGHT.bold, color: COLORS.white },

  signInRow:   { flexDirection: 'row', justifyContent: 'center' },
  signInLabel: { fontSize: FONT_SIZE.sm, color: COLORS.textMuted },
  signInLink:  { fontSize: FONT_SIZE.sm, color: COLORS.secondary, fontWeight: FONT_WEIGHT.bold },
});
