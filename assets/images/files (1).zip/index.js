// app/index.js  — Login Screen
import React, { useState, useRef, useEffect } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity,
  Animated, KeyboardAvoidingView, Platform,
  ScrollView, Alert,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import FormInput from '../components/FormInput';
import {
  COLORS, FONT_SIZE, FONT_WEIGHT, RADIUS, SPACING, shadow,
} from '../constants/theme';

export default function LoginScreen() {
  const router          = useRouter();
  const [email, setEmail]     = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading]   = useState(false);

  // Entry animations
  const logoY   = useRef(new Animated.Value(-40)).current;
  const logoOp  = useRef(new Animated.Value(0)).current;
  const cardY   = useRef(new Animated.Value(60)).current;
  const cardOp  = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.stagger(120, [
      Animated.parallel([
        Animated.timing(logoY,  { toValue: 0, duration: 600, useNativeDriver: true }),
        Animated.timing(logoOp, { toValue: 1, duration: 600, useNativeDriver: true }),
      ]),
      Animated.parallel([
        Animated.timing(cardY,  { toValue: 0, duration: 600, useNativeDriver: true }),
        Animated.timing(cardOp, { toValue: 1, duration: 600, useNativeDriver: true }),
      ]),
    ]).start();
  }, []);

  const handleLogin = () => {
    if (!email.trim() || !password.trim()) {
      Alert.alert('Missing Fields', 'Please enter your email and password.');
      return;
    }
    setLoading(true);
    // Simulate API call
    setTimeout(() => {
      setLoading(false);
      router.replace('/patient/registration');
    }, 1400);
  };

  return (
    <LinearGradient
      colors={[COLORS.primary, COLORS.primaryMid, '#2E86AB']}
      style={styles.gradient}
      start={{ x: 0, y: 0 }}
      end={{ x: 1, y: 1 }}
    >
      <SafeAreaView style={styles.safe}>
        <KeyboardAvoidingView
          behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
          style={{ flex: 1 }}
        >
          <ScrollView
            contentContainerStyle={styles.scroll}
            showsVerticalScrollIndicator={false}
            keyboardShouldPersistTaps="handled"
          >
            {/* Logo / Brand */}
            <Animated.View
              style={[styles.logoArea, { opacity: logoOp, transform: [{ translateY: logoY }] }]}
            >
              <View style={styles.logoCircle}>
                <Ionicons name="heart-circle" size={44} color={COLORS.secondary} />
              </View>
              <Text style={styles.brandName}>CareGiver</Text>
              <Text style={styles.brandTagline}>Smart Vitals Management</Text>
            </Animated.View>

            {/* Card */}
            <Animated.View
              style={[styles.card, { opacity: cardOp, transform: [{ translateY: cardY }] }]}
            >
              <Text style={styles.cardTitle}>Welcome back</Text>
              <Text style={styles.cardSub}>Sign in to your caregiver account</Text>

              <FormInput
                label="Email Address"
                value={email}
                onChangeText={setEmail}
                placeholder="you@hospital.com"
                keyboardType="email-address"
                autoCapitalize="none"
                icon="mail-outline"
                required
              />
              <FormInput
                label="Password"
                value={password}
                onChangeText={setPassword}
                placeholder="Enter password"
                secureTextEntry
                icon="lock-closed-outline"
                required
              />

              <TouchableOpacity
                style={styles.forgotLink}
                onPress={() => router.push('/forgot-password')}
              >
                <Text style={styles.forgotText}>Forgot password?</Text>
              </TouchableOpacity>

              {/* Login Button */}
              <TouchableOpacity
                style={[styles.loginBtn, loading && styles.loginBtnDisabled]}
                onPress={handleLogin}
                disabled={loading}
                activeOpacity={0.85}
              >
                <LinearGradient
                  colors={[COLORS.secondary, COLORS.primaryLight]}
                  style={styles.loginBtnGrad}
                  start={{ x: 0, y: 0 }}
                  end={{ x: 1, y: 0 }}
                >
                  {loading
                    ? <Text style={styles.loginBtnText}>Signing in…</Text>
                    : (
                      <>
                        <Text style={styles.loginBtnText}>Sign In</Text>
                        <Ionicons name="arrow-forward" size={18} color={COLORS.white} style={{ marginLeft: 8 }} />
                      </>
                    )}
                </LinearGradient>
              </TouchableOpacity>

              {/* Divider */}
              <View style={styles.divider}>
                <View style={styles.dividerLine} />
                <Text style={styles.dividerText}>or continue with</Text>
                <View style={styles.dividerLine} />
              </View>

              {/* Social row */}
              <View style={styles.socialRow}>
                {[
                  { icon: 'logo-google', label: 'Google' },
                  { icon: 'logo-apple',  label: 'Apple'  },
                ].map((s) => (
                  <TouchableOpacity key={s.label} style={styles.socialBtn}>
                    <Ionicons name={s.icon} size={20} color={COLORS.textBody} />
                    <Text style={styles.socialBtnText}>{s.label}</Text>
                  </TouchableOpacity>
                ))}
              </View>

              {/* Register link */}
              <View style={styles.registerRow}>
                <Text style={styles.registerLabel}>Don't have an account? </Text>
                <TouchableOpacity onPress={() => router.push('/register')}>
                  <Text style={styles.registerLink}>Create Account</Text>
                </TouchableOpacity>
              </View>
            </Animated.View>

            {/* Footer */}
            <Text style={styles.footer}>© 2025 CareGiver · HIPAA Compliant</Text>
          </ScrollView>
        </KeyboardAvoidingView>
      </SafeAreaView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  gradient:   { flex: 1 },
  safe:       { flex: 1 },
  scroll:     { flexGrow: 1, alignItems: 'center', paddingHorizontal: SPACING.lg, paddingBottom: SPACING.xl },

  logoArea:   { alignItems: 'center', marginTop: SPACING.xxl, marginBottom: SPACING.xl },
  logoCircle: { width: 80, height: 80, borderRadius: 40, backgroundColor: 'rgba(255,255,255,0.15)', alignItems: 'center', justifyContent: 'center', marginBottom: SPACING.md, ...shadow.md },
  brandName:  { fontSize: FONT_SIZE.xxxl, fontWeight: FONT_WEIGHT.extrabold, color: COLORS.white, letterSpacing: -0.5 },
  brandTagline: { fontSize: FONT_SIZE.sm, color: 'rgba(255,255,255,0.72)', marginTop: 4, letterSpacing: 0.3 },

  card:       { width: '100%', backgroundColor: COLORS.white, borderRadius: RADIUS.xl, padding: SPACING.lg, ...shadow.lg },
  cardTitle:  { fontSize: FONT_SIZE.xxl, fontWeight: FONT_WEIGHT.bold, color: COLORS.textDark, marginBottom: 4 },
  cardSub:    { fontSize: FONT_SIZE.sm, color: COLORS.textMuted, marginBottom: SPACING.lg },

  forgotLink: { alignSelf: 'flex-end', marginTop: -SPACING.sm, marginBottom: SPACING.md },
  forgotText: { fontSize: FONT_SIZE.sm, color: COLORS.secondary, fontWeight: FONT_WEIGHT.semibold },

  loginBtn:       { borderRadius: RADIUS.md, overflow: 'hidden', ...shadow.sm, marginBottom: SPACING.lg },
  loginBtnDisabled: { opacity: 0.7 },
  loginBtnGrad:   { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', paddingVertical: 15 },
  loginBtnText:   { fontSize: FONT_SIZE.md, fontWeight: FONT_WEIGHT.bold, color: COLORS.white, letterSpacing: 0.3 },

  divider:     { flexDirection: 'row', alignItems: 'center', marginBottom: SPACING.md },
  dividerLine: { flex: 1, height: 1, backgroundColor: COLORS.divider },
  dividerText: { marginHorizontal: SPACING.sm, fontSize: FONT_SIZE.xs, color: COLORS.textMuted },

  socialRow:     { flexDirection: 'row', gap: SPACING.sm, marginBottom: SPACING.lg },
  socialBtn:     { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', borderWidth: 1.5, borderColor: COLORS.divider, borderRadius: RADIUS.md, paddingVertical: 11, gap: 8, ...shadow.xs },
  socialBtnText: { fontSize: FONT_SIZE.sm, fontWeight: FONT_WEIGHT.semibold, color: COLORS.textBody },

  registerRow:  { flexDirection: 'row', justifyContent: 'center', alignItems: 'center' },
  registerLabel:{ fontSize: FONT_SIZE.sm, color: COLORS.textMuted },
  registerLink: { fontSize: FONT_SIZE.sm, fontWeight: FONT_WEIGHT.bold, color: COLORS.secondary },

  footer: { marginTop: SPACING.xl, fontSize: FONT_SIZE.xs, color: 'rgba(255,255,255,0.45)', letterSpacing: 0.3 },
});
