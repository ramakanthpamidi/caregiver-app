// app/patient/vitals/thermometer.js
import DeviceScreen from '../../../components/DeviceScreen';
import { COLORS } from '../../../constants/theme';

const CONFIG = {
  id:           'thermometer',
  name:         'Thermometer',
  emoji:        '🌡️',
  color:        COLORS.deviceThermo,
  instructions: 'Place the probe under the patient\'s tongue or in the axilla as per your protocol. Ask the patient to keep their mouth closed. Do not take orally if patient has eaten or drunk in the past 15 minutes.',
  readings: [
    { key: 'tempC', label: 'Temperature (°C)', unit: '°C', simulate: () => (Math.random() * 2 + 36.0).toFixed(1) },
    { key: 'tempF', label: 'Temperature (°F)', unit: '°F', simulate: () => (Math.random() * 3.6 + 96.8).toFixed(1) },
    { key: 'site',  label: 'Measurement Site', unit: '',   simulate: () => ['Oral', 'Axillary', 'Tympanic'][Math.floor(Math.random() * 3)] },
  ],
};

export default function ThermometerScreen() {
  return <DeviceScreen config={CONFIG} />;
}
