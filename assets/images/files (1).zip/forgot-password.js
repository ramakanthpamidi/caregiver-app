// app/forgot-password.js — Forgot Password Screen
import React, { useState, useRef } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity,
  ScrollView, KeyboardAvoidingView, Platform,
  Alert, TextInput,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import FormInput from '../components/FormInput';
import { COLORS, FONT_SIZE, FONT_WEIGHT, RADIUS, SPACING, shadow } from '../constants/theme';

const OTP_LENGTH = 6;

export default function ForgotPasswordScreen() {
  const router = useRouter();
  const [phase, setPhase]         = useState('email');   // email | otp | reset | done
  const [email, setEmail]         = useState('');
  const [otp, setOtp]             = useState(Array(OTP_LENGTH).fill(''));
  const [newPass, setNewPass]     = useState('');
  const [confirmPass, setConfirmPass] = useState('');
  const [loading, setLoading]     = useState(false);
  const [resendTimer, setResendTimer] = useState(0);
  const otpRefs = useRef([]);
  const timerRef = useRef(null);

  const startResendTimer = () => {
    setResendTimer(30);
    timerRef.current = setInterval(() => {
      setResendTimer((t) => {
        if (t <= 1) { clearInterval(timerRef.current); return 0; }
        return t - 1;
      });
    }, 1000);
  };

  const handleSendCode = () => {
    if (!email.trim()) { Alert.alert('Required', 'Please enter your email address.'); return; }
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      setPhase('otp');
      startResendTimer();
    }, 1500);
  };

  const handleOtpChange = (text, index) => {
    const next = [...otp];
    next[index] = text.slice(-1);
    setOtp(next);
    if (text && index < OTP_LENGTH - 1) {
      otpRefs.current[index + 1]?.focus();
    }
  };

  const handleOtpKeyPress = (key, index) => {
    if (key === 'Backspace' && !otp[index] && index > 0) {
      otpRefs.current[index - 1]?.focus();
    }
  };

  const handleVerifyOtp = () => {
    const code = otp.join('');
    if (code.length < OTP_LENGTH) { Alert.alert('Incomplete', 'Please enter the full 6-digit code.'); return; }
    setLoading(true);
    setTimeout(() => { setLoading(false); setPhase('reset'); }, 1200);
  };

  const handleResetPassword = () => {
    if (newPass.length < 8) { Alert.alert('Weak', 'Password must be at least 8 characters.'); return; }
    if (newPass !== confirmPass) { Alert.alert('Mismatch', 'Passwords do not match.'); return; }
    setLoading(true);
    setTimeout(() => { setLoading(false); setPhase('done'); }, 1400);
  };

  const PHASES = {
    email: {
      icon: 'mail-open-outline',
      title: 'Forgot Password?',
      subtitle: 'Enter your registered email address and we'll send you a verification code.',
    },
    otp: {
      icon: 'shield-checkmark-outline',
      title: 'Verify Your Identity',
      subtitle: `We sent a ${OTP_LENGTH}-digit code to ${email}. Check your inbox.`,
    },
    reset: {
      icon: 'lock-open-outline',
      title: 'Set New Password',
      subtitle: 'Choose a strong new password for your account.',
    },
    done: {
      icon: 'checkmark-circle-outline',
      title: 'Password Reset!',
      subtitle: 'Your password has been successfully updated. You can now sign in.',
    },
  };

  const current = PHASES[phase];

  return (
    <SafeAreaView style={styles.safe}>
      <LinearGradient colors={[COLORS.primary, COLORS.primaryMid]} style={styles.header}>
        <TouchableOpacity style={styles.backBtn} onPress={() => router.back()}>
          <Ionicons name="chevron-back" size={22} color={COLORS.white} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Account Recovery</Text>
      </LinearGradient>

      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={{ flex: 1 }}>
        <ScrollView contentContainerStyle={styles.body} showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled">

          {/* Phase Icon */}
          <View style={[styles.iconRing, phase === 'done' && { backgroundColor: COLORS.successBg }]}>
            <Ionicons
              name={current.icon}
              size={40}
              color={phase === 'done' ? COLORS.success : COLORS.secondary}
            />
          </View>

          <Text style={styles.title}>{current.title}</Text>
          <Text style={styles.subtitle}>{current.subtitle}</Text>

          {/* ─── Email Phase ─── */}
          {phase === 'email' && (
            <View style={styles.card}>
              <FormInput
                label="Email Address"
                value={email}
                onChangeText={setEmail}
                placeholder="you@hospital.com"
                keyboardType="email-address"
                autoCapitalize="none"
                icon="mail-outline"
                required
              />
              <TouchableOpacity
                style={[styles.primaryBtn, loading && { opacity: 0.7 }]}
                onPress={handleSendCode}
                disabled={loading}
              >
                <Text style={styles.primaryBtnText}>{loading ? 'Sending…' : 'Send Verification Code'}</Text>
              </TouchableOpacity>
            </View>
          )}

          {/* ─── OTP Phase ─── */}
          {phase === 'otp' && (
            <View style={styles.card}>
              <Text style={styles.otpLabel}>Enter 6-Digit Code</Text>
              <View style={styles.otpRow}>
                {Array(OTP_LENGTH).fill(null).map((_, i) => (
                  <TextInput
                    key={i}
                    ref={(ref) => { otpRefs.current[i] = ref; }}
                    style={[styles.otpBox, otp[i] && styles.otpBoxFilled]}
                    value={otp[i]}
                    onChangeText={(t) => handleOtpChange(t, i)}
                    onKeyPress={({ nativeEvent: { key } }) => handleOtpKeyPress(key, i)}
                    keyboardType="number-pad"
                    maxLength={1}
                    textAlign="center"
                  />
                ))}
              </View>

              <TouchableOpacity
                style={[styles.primaryBtn, loading && { opacity: 0.7 }]}
                onPress={handleVerifyOtp}
                disabled={loading}
              >
                <Text style={styles.primaryBtnText}>{loading ? 'Verifying…' : 'Verify Code'}</Text>
              </TouchableOpacity>

              <View style={styles.resendRow}>
                <Text style={styles.resendLabel}>Didn't receive it? </Text>
                {resendTimer > 0
                  ? <Text style={styles.resendTimer}>Resend in {resendTimer}s</Text>
                  : (
                    <TouchableOpacity onPress={() => { startResendTimer(); handleSendCode(); }}>
                      <Text style={styles.resendLink}>Resend Code</Text>
                    </TouchableOpacity>
                  )
                }
              </View>
            </View>
          )}

          {/* ─── Reset Phase ─── */}
          {phase === 'reset' && (
            <View style={styles.card}>
              <FormInput label="New Password" value={newPass} onChangeText={setNewPass} placeholder="Min. 8 characters" secureTextEntry icon="lock-closed-outline" required hint="Use a mix of letters, numbers, and symbols." />
              <FormInput label="Confirm Password" value={confirmPass} onChangeText={setConfirmPass} placeholder="Re-enter new password" secureTextEntry icon="lock-closed-outline" required />
              <TouchableOpacity
                style={[styles.primaryBtn, loading && { opacity: 0.7 }]}
                onPress={handleResetPassword}
                disabled={loading}
              >
                <Text style={styles.primaryBtnText}>{loading ? 'Updating…' : 'Update Password'}</Text>
              </TouchableOpacity>
            </View>
          )}

          {/* ─── Done Phase ─── */}
          {phase === 'done' && (
            <View style={styles.card}>
              <View style={styles.successBox}>
                <Ionicons name="checkmark-circle" size={48} color={COLORS.success} />
                <Text style={styles.successTitle}>All done!</Text>
                <Text style={styles.successSub}>Your password has been reset. Sign in with your new credentials.</Text>
              </View>
              <TouchableOpacity style={styles.primaryBtn} onPress={() => router.replace('/')}>
                <Ionicons name="log-in-outline" size={18} color={COLORS.white} style={{ marginRight: 8 }} />
                <Text style={styles.primaryBtnText}>Go to Sign In</Text>
              </TouchableOpacity>
            </View>
          )}

        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe:        { flex: 1, backgroundColor: COLORS.background },
  header:      { flexDirection: 'row', alignItems: 'center', paddingHorizontal: SPACING.md, paddingVertical: SPACING.md, gap: SPACING.sm },
  backBtn:     { padding: 6, borderRadius: RADIUS.full, backgroundColor: 'rgba(255,255,255,0.15)' },
  headerTitle: { fontSize: FONT_SIZE.lg, fontWeight: FONT_WEIGHT.bold, color: COLORS.white },

  body:        { flexGrow: 1, alignItems: 'center', paddingHorizontal: SPACING.lg, paddingVertical: SPACING.xl },

  iconRing:    { width: 90, height: 90, borderRadius: 45, backgroundColor: COLORS.accentLight + '30', alignItems: 'center', justifyContent: 'center', marginBottom: SPACING.lg, ...shadow.sm },
  title:       { fontSize: FONT_SIZE.xxl, fontWeight: FONT_WEIGHT.bold, color: COLORS.textDark, textAlign: 'center', marginBottom: SPACING.sm },
  subtitle:    { fontSize: FONT_SIZE.sm, color: COLORS.textMuted, textAlign: 'center', lineHeight: 20, marginBottom: SPACING.xl, paddingHorizontal: SPACING.md },

  card:        { width: '100%', backgroundColor: COLORS.white, borderRadius: RADIUS.lg, padding: SPACING.lg, ...shadow.sm },

  primaryBtn:  { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', backgroundColor: COLORS.secondary, paddingVertical: 15, borderRadius: RADIUS.md, ...shadow.sm, marginTop: SPACING.sm },
  primaryBtnText: { fontSize: FONT_SIZE.md, fontWeight: FONT_WEIGHT.bold, color: COLORS.white },

  otpLabel:    { fontSize: FONT_SIZE.sm, fontWeight: FONT_WEIGHT.semibold, color: COLORS.textBody, marginBottom: SPACING.md, textAlign: 'center' },
  otpRow:      { flexDirection: 'row', justifyContent: 'space-between', marginBottom: SPACING.lg },
  otpBox:      { width: 46, height: 56, borderRadius: RADIUS.md, borderWidth: 2, borderColor: COLORS.divider, backgroundColor: COLORS.surface, fontSize: FONT_SIZE.xl, fontWeight: FONT_WEIGHT.bold, color: COLORS.textDark },
  otpBoxFilled:{ borderColor: COLORS.secondary, backgroundColor: COLORS.accentLight + '20' },

  resendRow:   { flexDirection: 'row', justifyContent: 'center', marginTop: SPACING.md },
  resendLabel: { fontSize: FONT_SIZE.sm, color: COLORS.textMuted },
  resendLink:  { fontSize: FONT_SIZE.sm, color: COLORS.secondary, fontWeight: FONT_WEIGHT.bold },
  resendTimer: { fontSize: FONT_SIZE.sm, color: COLORS.textMuted },

  successBox:  { alignItems: 'center', paddingVertical: SPACING.lg, gap: SPACING.sm },
  successTitle:{ fontSize: FONT_SIZE.xl, fontWeight: FONT_WEIGHT.bold, color: COLORS.success },
  successSub:  { fontSize: FONT_SIZE.sm, color: COLORS.textMuted, textAlign: 'center', lineHeight: 20 },
});
